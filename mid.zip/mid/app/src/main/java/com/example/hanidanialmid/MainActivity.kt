package com.example.hanidanialmid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val login = findViewById<Button>(R.id.btnLogin)
        val username = findViewById<EditText>(R.id.usernameBox)
        var name = username.text
        val password = findViewById<EditText>(R.id.passwordBox)
        var pass = password.text

        login.setOnClickListener({

            if (name.isEmpty() && pass.isEmpty())
            {
                Toast.makeText(this,"Please Enter Username and Password First",
                Toast.LENGTH_SHORT).show()
            }

            else if (name.isEmpty())
        {
            Toast.makeText(this, "Please Enter Username", Toast.LENGTH_SHORT).show()
        }
        else if (pass.isEmpty())
        {
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_SHORT).show()
        }
        else if (name.toString() != "Abu" && pass.toString() != "1234")
            {
                Toast.makeText(this, "Invalid Username and Password", Toast.LENGTH_SHORT).show()
            }
            else if (name.toString() != "Abu")
            {
                Toast.makeText(this, "Invalid Username", Toast.LENGTH_SHORT).show()
            }
            else if (pass.toString() != "1234")
            {
                Toast.makeText(this, "Invalid Password", Toast.LENGTH_SHORT).show()
            }
            else if (name.toString() == "Abu" && pass.toString() == "1234")
            {
                val intent = Intent(applicationContext,MainActivity2::class.java)
                startActivity(intent)
            }
        })

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}