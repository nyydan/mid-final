package com.example.hanidanialmid

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity7 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main7)

        val goNextPage = findViewById<Button>(R.id.button)

        goNextPage.setOnClickListener({
            val intent = Intent(applicationContext,MainActivity8::class.java)

            startActivity(intent)
        })

        val goMainPage = findViewById<Button>(R.id.button2)

        goMainPage.setOnClickListener({
            val intent = Intent(applicationContext,MainActivity4::class.java)

            startActivity(intent)
        })
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}